import React from 'react';
import Map from '../components/common/Map';
import {
    Container,
    Row,
    Col,
    Card,
    CardBody,
} from "shards-react";

import PageTitle from "../components/common/PageTitle";

class GoogleMap extends React.Component {
    constructor(props) {
        super(props);
  
        this.state = {
        };

        this.initMap = this.initMap.bind(this);
    }

    initMap(map){
        this.map = map;        
    }

    render() {
        return (
            <Container fluid className="main-content-container px-4">
                <Row noGutters className="page-header py-4">
                    <PageTitle sm="4" title="Google Maps" subtitle="Components" className="text-sm-left" />
                </Row>
                <Row>
                    <Col md="12">                    
                        <Card className="card-post mb-4">
                            <CardBody>
                                <div style={{ width: '100%', height: '500px', boxSizing: 'border-box' }}>
                                    <Map
                                        init={this.initMap.bind(this)}
                                        location={{ latitude: -19.8157, longitude: -43.9542 }}
                                        zoom={5}
                                    />
                                </div>
                            </CardBody>
                        </Card>
                    </Col>
                </Row>
            </Container>
        )
    }
}


export default GoogleMap;
