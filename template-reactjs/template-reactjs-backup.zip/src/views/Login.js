import React from "react";
import { Link } from "react-router-dom";
import {
  Container,
  Row,
  Col,
  Card,    
  Form,
  Button,
  FormInput,
  FormGroup,
  CardBody,
  CardImg, 
} from "shards-react";

class Login extends React.Component {
    constructor(props) {
        super(props);    
        this.state = {            
            emailLogin: "",
            passwordLogin: "",	
        };        
        this.onChangeEmail = this.onChangeEmail.bind(this);
        this.onChangePassword = this.onChangePassword.bind(this);
    }

    onChangeEmail(e) {
        this.setState({emailLogin: e.target.value});
    }

    onChangePassword(e) {
        this.setState({passwordLogin: e.target.value});
    }

    render() {
        return (
            <main>
                <Container>
                    <Row>
                        <Col className="d-flex justify-content-center mt-5">
                            <Card>
                                {/*<CardHeader className="border-bottom">
                                    <h5 className="m-0">Login</h5>
                                </CardHeader>*/}                                
                                <CardBody>
                                    <CardImg src="https://place-hold.it/300x150" className="mb-3"/>
                                    <Form>
                                        <FormGroup>
                                            <FormInput 
                                                required                        
                                                type="email"
                                                placeholder="Email" 
                                                value={this.state.emailLogin}
                                                onChange={this.onChangeEmail}
                                            />
                                        </FormGroup>
                                        <FormGroup>
                                            <FormInput
                                                required
                                                type="password"
                                                placeholder="Password"
                                                value={this.state.passwordLogin}
                                                onChange={this.onChangePassword}
                                            />
                                        </FormGroup>                                                                             
                                        <Button theme="primary" block>Entrar</Button>
                                    </Form>
                                    <div className="my-2 text-center">
                                        <Link to="/user-profile-lite"><span className="txt-holos">Esqueceu sua senha?</span></Link>
                                    </div>                          
                                    <Row className="justify-content-around">
                                        <i className="fab fa-facebook-square fa-2x"></i>
                                        <i className="fab fa-instagram fa-2x"></i>
                                        <i className="fab fa-twitter-square fa-2x"></i>
                                    </Row>
                                </CardBody>
                            </Card>                            
                        </Col>
                    </Row>
                </Container>
            </main>            
        )
    }
}

export default Login;
