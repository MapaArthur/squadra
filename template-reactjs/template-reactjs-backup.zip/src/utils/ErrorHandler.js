import React from "react";
import { Redirect } from 'react-router';

export default class ErrorHandler extends React.Component {
    constructor(props) {
		super(props)
		this.state = { errorOccurred: false }
    }
  
    componentDidCatch(error, info) {
		this.setState({ errorOccurred: true })
    }
  
    render() {
      	return this.state.errorOccurred ? <Redirect to="/errors"/> : this.props.children
    }
}