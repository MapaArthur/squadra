import React from "react";
import { NavLink as RouteNavLink } from "react-router-dom";
import { NavItem, NavLink, Collapse } from "shards-react";

export default class SidebarNavItem extends React.Component {
  constructor(props) {
    super(props);  
    this.state = { 
      collapse: false 
    };
    this.toggle = this.toggle.bind(this);
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  render() {
    return (
      <div>
        {this.props.navItem.type === "Collapse" ?
            <div>
              <NavItem onClick={this.toggle}>
                <NavLink>
                  {this.props.navItem.htmlBefore && (
                    <div
                      className="d-inline-block item-icon-wrapper"
                      dangerouslySetInnerHTML={{ __html: this.props.navItem.htmlBefore }}
                    />
                  )}
                  {this.props.navItem.title && <span>{this.props.navItem.title}</span>}
                  {this.props.navItem.htmlAfter && (
                    <div
                      className="d-inline-block item-icon-wrapper"
                      dangerouslySetInnerHTML={{ __html: this.props.navItem.htmlAfter }}
                    />
                  )}
                </NavLink>
              </NavItem>
              <Collapse open={this.state.collapse}>
                {this.props.navItem.items.map((item, index) => {
                  return (
                    <NavItem className="ml-3" key={index}>
                      <NavLink tag={RouteNavLink} to={item.to}>
                        {item.htmlBefore && (
                          <div
                            className="d-inline-block item-icon-wrapper"
                            dangerouslySetInnerHTML={{ __html: item.htmlBefore }}
                          />
                        )}
                        {item.title && <span>{item.title}</span>}
                        {item.htmlAfter && (
                          <div
                            className="d-inline-block item-icon-wrapper"
                            dangerouslySetInnerHTML={{ __html: item.htmlAfter }}
                          />
                        )}
                      </NavLink>  
                    </NavItem>       
                  )
                })}
              </Collapse>
            </div>
          : <NavItem>
              <NavLink tag={RouteNavLink} to={this.props.navItem.to}>
                {this.props.navItem.htmlBefore && (
                  <div
                    className="d-inline-block item-icon-wrapper"
                    dangerouslySetInnerHTML={{ __html: this.props.navItem.htmlBefore }}
                  />
                )}
                {this.props.navItem.title && <span>{this.props.navItem.title}</span>}
                {this.props.navItem.htmlAfter && (
                  <div
                    className="d-inline-block item-icon-wrapper"
                    dangerouslySetInnerHTML={{ __html: this.props.navItem.htmlAfter }}
                  />
                )}
              </NavLink>
            </NavItem>
          }      
      </div>
    );
  }
}
