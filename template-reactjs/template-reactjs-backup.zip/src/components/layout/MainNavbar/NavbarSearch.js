import React from "react";
import {
  Form,
  InputGroup,
  InputGroupAddon,
  FormInput,
  Button,
  Container
} from "shards-react";

export default () => (
  <Container className="main-navbar__search d-none d-md-flex d-lg-flex justify-content-center">
    <Form className="w-50">
      <InputGroup>      
        <FormInput
          className="bg-light-gray"
          placeholder="Search"
        />
        <InputGroupAddon type="append">
            <Button squared theme="secondary"><i className="fas fa-search"/></Button>
        </InputGroupAddon>
      </InputGroup>
    </Form>
  </Container>  
);
