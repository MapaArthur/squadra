import DefaultLayout from "./Default";
import NoLayout from "./NoLayout";

export { DefaultLayout, NoLayout };
