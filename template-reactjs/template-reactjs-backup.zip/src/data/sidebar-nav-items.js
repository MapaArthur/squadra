export default function() {
  return [
    {
      type: "Item",
      title: "Blog Dashboard",
      to: "/blog-overview",
      htmlBefore: '<i class="material-icons">edit</i>',
      htmlAfter: ""
    },
    {
      type: "Collapse",
      title: "Components",
      htmlBefore: '<i class="fas fa-align-justify"></i>',
      items: [        
        {
          title: "Google Maps",
          htmlBefore: '<i class="fas fa-map-marker-alt"></i>',
          to: "/google-map",
        },
        {
          title: "Login",
          htmlBefore: '<i class="fas fa-user"></i>',
          to: "/login",
        }
      ]      
    },
    {
      type: "Item",
      title: "User Profile",
      htmlBefore: '<i class="material-icons">person</i>',
      to: "/user-profile-lite",
    }, 
    {
      type: "Item",
      title: "Blog Posts",
      htmlBefore: '<i class="material-icons">vertical_split</i>',
      to: "/blog-posts",
    },
    {
      type: "Item",
      title: "Add New Post",
      htmlBefore: '<i class="material-icons">note_add</i>',
      to: "/add-new-post",
    },
    {
      type: "Item",
      title: "Forms & Components",
      htmlBefore: '<i class="material-icons">view_module</i>',
      to: "/components-overview",
    },
    {
      type: "Item",
      title: "Tables",
      htmlBefore: '<i class="material-icons">table_chart</i>',
      to: "/tables",
    },   
    {
      type: "Item",
      title: "Errors",
      htmlBefore: '<i class="material-icons">error</i>',
      to: "/errors",
    }
  ];
}
