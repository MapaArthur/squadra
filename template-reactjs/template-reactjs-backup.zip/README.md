<p align="center">
<a href="https://designrevision.com/downloads/shards-dashboard-lite-react/">
<img src="assets/preview.png" width="250" />
</a>
</p>

<h1 align="center" style="border-bottom: none !important; margin-bottom: 5px !important;"><a href="https://designrevision.com/downloads/shards-dashboard-lite-react/">Shards Dashboard React</a></h1>
<p align="center">
  <a href="#">
    <img src="https://img.shields.io/badge/License-MIT-brightgreen.svg" />
  </a>
  <a href="https://twitter.com/designrevision">
    <img src="https://img.shields.io/twitter/follow/DesignRevision.svg?style=social&label=Follow" />
  </a>
</p>

<p align="center">
A free React admin dashboard template pack featuring a modern design system <br />  and lots of custom templates and components.
</p>

<p align="center">
  <a href="https://designrevision.com/demo/shards-dashboard-lite-react">
    <img height="55px" src="assets/btn-live-preview.png" />
  </a>
  <a href="https://designrevision.com/downloads/shards-dashboard-lite-react">
    <img height="55px" src="assets/btn-learn-more.png" />
  </a>
</p>

<br />

<p align="center">
<a href="https://designrevision.com/downloads/shards-dashboard-lite-react">
<img src="assets/demo-preview.gif" width="650" />
</a>
</p>

<br />

> ✨ **Note:** You can download the Sketch files from the official product page.

<br />

### Quick Start

* Install dependencies by running `yarn` or `npm install`.
* Run `yarn start` or `npm run start` to start the local development server.
* 😎 **That's it!** You're ready to start building awesome dashboards.

<br />

### Project Structure

- This project is bootstrapped using [Create React App](https://github.com/facebook/create-react-app).
- **Flux** is used for state management and all Flux specific files are located inside `src/flux`. Transitioning to a more robust solution such as Redux is also fairly simple.
- Rotas podem ser definidas no module `src/routes.js` com path, layout e component.
- Todos os templates primários estão localizados dentro de `src/views`.
- O diretório `src/components` possui os subcomponentes específicos de cada template primário em seus subdiretórios.
- O diretório `src/utils` contém exemplos genéricos de Chart.js.
- Os styles do layout herdados do Shards Dashboard são puxados do submódulo `src/shards-dashboard` dentro de `src/App.js`.
- Outros styles extras específicos das bibliotecas usadas estão localizadas dentro de `src/assets`.
- Os layouts estão localizados no diretório `src/layouts`. O layout padrão (`src/layouts/Default.js`) consiste em navbar, sidebar e footer, entretando, é possível criar e usar novos layouts assim como seus styles.
- Para o layout padrão (`src/layouts/Default.js`) é possível alterar as cores de cada item (navbar, sidebar e footer) individualmente no arquivo css (`src/layouts/Default.css`).
- É possível criar items e items com subitems do sidebar no module `src/data/sidebar-nav-items.js` com os atributos: type (Item ou Collapse), title (nome de exibição), htmlBefore (icon antes do title), htmlAfter (icon depois do title). Tipos Collapse possuem subitems: items (array de Item) e os tipos Item possuem um caminho: to (path).
- É possível alterar a logo da empresa e o texto que aparecem no sidebar em `src/components/layout/MainSidebar/SidebarMainNavbar.js`. É possível também remover o texto e mostrar somente a logo passando props `hideLogoText={true}` ao chamar `<MainSidebar/>` no layout usado.
- Existem vários componentes de exemplo que devem ser removidos ao iniciar um projeto.
<br />

### Available Scripts

### `npm start`

Runs the app in the development mode.

### `npm test`

Launches the test runner in the interactive watch mode.

### `npm run build`

Builds the app for production to the `build` folder.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can’t go back!**

If you aren’t satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.


<br />

### 🌟 Pro Version

If you're looking for something more, check out [Shards Dashboard Pro React](https://designrevision.com/downloads/shards-dashboard-pro-react/) which features many more custom templates and components. Use the `GITHUB15` coupon code for a **15% discount off the current price**.

<br />

### Built using

- [Shards React](https://github.com/designrevision/shards-react)
- [Chart.js](https://www.chartjs.org/)
- [Flux](https://facebook.github.io/flux/)
- [No UI Slider](https://refreshless.com/nouislider/)
- [React Datepicker](https://www.npmjs.com/package/react-datepicker)
- [Quill](https://quilljs.com/)

<br />

### Changelog

Please check out the [CHANGELOG](CHANGELOG.md).
